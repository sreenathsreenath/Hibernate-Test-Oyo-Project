package com.java.hiber;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Billing")
public class Billing {
	
	
	@Id
	@Column(name="BillingId")
	private int billingid;
	
	@Column(name="BookID")
	private String bookid;
	
	@Column(name="RoomID")
	private String roomid;
	
	@Column(name="NoOfDays")
	private int no_of_days;
	
	@Column(name="BillAmt")
	private int billamt;

	public Billing() {
		// TODO Auto-generated constructor stub
	}

	public int getBillingid() {
		return billingid;
	}

	public void setBillingid(int billingid) {
		this.billingid = billingid;
	}

	public String getBookid() {
		return bookid;
	}

	public void setBookid(String bookid) {
		this.bookid = bookid;
	}

	public String getRoomid() {
		return roomid;
	}

	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}

	public int getNo_of_days() {
		return no_of_days;
	}

	public void setNo_of_days(int no_of_days) {
		this.no_of_days = no_of_days;
	}

	public int getBillamt() {
		return billamt;
	}

	public void setBillamt(int billamt) {
		this.billamt = billamt;
	}

}
