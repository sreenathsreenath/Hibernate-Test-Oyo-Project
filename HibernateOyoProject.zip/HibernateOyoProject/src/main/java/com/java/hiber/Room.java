package com.java.hiber;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Room")
public class Room {
	
	@Id
	@Column(name="RoomID")
	private String roomid;
	@Column(name="Type")
	private String type;
	@Column(name="Status")
	private String status;
	@Column(name="CostPerDay")
	private int costperday;
	
	
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getCostperday() {
		return costperday;
	}
	public void setCostperday(int costperday) {
		this.costperday = costperday;
	}
	public Room() {
		
		// TODO Auto-generated constructor stub
	}
	

}
