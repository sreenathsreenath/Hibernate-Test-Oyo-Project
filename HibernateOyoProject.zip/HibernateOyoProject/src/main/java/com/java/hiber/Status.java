package com.java.hiber;

public enum Status {	
	AVAILABLE,BOOKED
}
